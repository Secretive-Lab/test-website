/* ==========================================================================
   КУБОРИЯ — site interactions
   ========================================================================== */
(() => {
  "use strict";

  const $ = (selector, context = document) => context.querySelector(selector);
  const $$ = (selector, context = document) => Array.from(context.querySelectorAll(selector));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* Footer year ------------------------------------------------------------ */
  $$("[data-year]").forEach((el) => {
    el.textContent = String(new Date().getFullYear());
  });

  /* Sticky header ---------------------------------------------------------- */
  const header = $(".site-header");
  let scrollTick = false;

  function updateHeader() {
    if (!header) return;
    header.classList.toggle("is-scrolled", window.scrollY > 8);
    scrollTick = false;
  }

  if (header) {
    updateHeader();
    window.addEventListener(
      "scroll",
      () => {
        if (!scrollTick) {
          window.requestAnimationFrame(updateHeader);
          scrollTick = true;
        }
      },
      { passive: true }
    );
  }

  /* Toast ------------------------------------------------------------------ */
  let toastEl = null;
  let toastTimer = null;

  function showToast(message) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.className = "toast";
      toastEl.setAttribute("role", "status");
      toastEl.setAttribute("aria-live", "polite");
      toastEl.innerHTML = '<span class="toast__dot"></span><span class="toast__text"></span>';
      document.body.appendChild(toastEl);
    }

    $(".toast__text", toastEl).textContent = message;
    window.requestAnimationFrame(() => toastEl.classList.add("is-visible"));
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      toastEl.classList.remove("is-visible");
    }, 4200);
  }

  /* Copy to clipboard ------------------------------------------------------ */
  function fallbackCopy(text) {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.top = "-9999px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (error) {
      ok = false;
    }
    document.body.removeChild(textarea);
    if (!ok) throw new Error("copy failed");
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(text);
        return;
      } catch (error) {
        /* fall through to the legacy path */
      }
    }
    fallbackCopy(text);
  }

  document.addEventListener("click", async (event) => {
    const trigger = event.target.closest("[data-copy]");
    if (!trigger) return;

    const text = trigger.getAttribute("data-copy");
    if (!text) return;

    try {
      await copyText(text);
      const isCommand = text.trim().startsWith("/");
      const message = isCommand
        ? `Команда скопирована: ${text}`
        : text.includes("kuboria.ru")
          ? `IP скопирован: ${text} — вперёд в игру!`
          : `Скопировано: ${text}`;
      showToast(message);
    } catch (error) {
      showToast(`Не удалось скопировать. Адрес: ${text}`);
    }
  });

  /* Mobile navigation ------------------------------------------------------ */
  const navToggle = $(".nav-toggle");
  const siteNav = $("#site-nav");

  function closeNav() {
    if (!navToggle || !siteNav) return;
    siteNav.classList.remove("is-open");
    navToggle.setAttribute("aria-expanded", "false");
    document.body.classList.remove("nav-open");
    header?.classList.remove("nav-open");
  }

  function openNav() {
    if (!navToggle || !siteNav) return;
    siteNav.classList.add("is-open");
    navToggle.setAttribute("aria-expanded", "true");
    document.body.classList.add("nav-open");
    header?.classList.add("nav-open");
  }

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      if (isOpen) {
        closeNav();
      } else {
        openNav();
      }
    });

    siteNav.addEventListener("click", (event) => {
      if (event.target.closest("a, [data-copy]")) closeNav();
    });

    document.addEventListener("click", (event) => {
      if (
        siteNav.classList.contains("is-open") &&
        !event.target.closest(".site-header")
      ) {
        closeNav();
      }
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth > 1024) closeNav();
    });
  }

  /* Reveal on scroll ------------------------------------------------------- */
  const revealItems = $$("[data-reveal]");

  if (revealItems.length) {
    if (reduceMotion || !("IntersectionObserver" in window)) {
      revealItems.forEach((el) => el.classList.add("is-visible"));
    } else {
      const revealObserver = new IntersectionObserver(
        (entries, observer) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          });
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
      );

      revealItems.forEach((el) => revealObserver.observe(el));
    }
  }

  /* Animated counters ------------------------------------------------------ */
  function animateCounter(el) {
    const target = Number.parseFloat(el.getAttribute("data-count"));
    if (Number.isNaN(target)) return;

    const decimals = Number.parseInt(el.getAttribute("data-decimals") || "0", 10);
    const formatter = new Intl.NumberFormat("ru-RU", {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });

    if (reduceMotion) {
      el.textContent = formatter.format(target);
      return;
    }

    const duration = 1400;
    const start = performance.now();

    function frame(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = formatter.format(target * eased);

      if (progress < 1) {
        window.requestAnimationFrame(frame);
      } else {
        el.textContent = formatter.format(target);
      }
    }

    window.requestAnimationFrame(frame);
  }

  const counters = $$("[data-count]");

  if (counters.length) {
    if (!("IntersectionObserver" in window)) {
      counters.forEach(animateCounter);
    } else {
      const counterObserver = new IntersectionObserver(
        (entries, observer) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            animateCounter(entry.target);
            observer.unobserve(entry.target);
          });
        },
        { threshold: 0.45 }
      );

      counters.forEach((el) => counterObserver.observe(el));
    }
  }

  /* Accordions: keep one panel open per group ------------------------------ */
  const accordions = $$(".accordion");

  accordions.forEach((details) => {
    details.addEventListener("toggle", () => {
      if (!details.open) return;
      const parent = details.parentElement;
      if (!parent) return;

      Array.from(parent.children).forEach((sibling) => {
        if (sibling !== details && sibling.tagName === "DETAILS" && sibling.open) {
          sibling.open = false;
        }
      });
    });
  });

  /* Rules filter ----------------------------------------------------------- */
  const rulesSearch = $("#rules-search");
  const rulesContent = $("#rules-content");

  if (rulesSearch && rulesContent) {
    const rules = $$("[data-rule]", rulesContent);
    const sections = $$("[data-rule-section]", rulesContent);
    const categoryButtons = $$("[data-rule-filter]");
    const emptyState = $("#rules-empty");
    const countEl = $("#rules-count");
    const resetButton = $("[data-rules-reset]");
    let activeCategory = "all";

    const normalize = (value) =>
      value
        .toLowerCase()
        .replace(/ё/g, "е")
        .replace(/\s+/g, " ")
        .trim();

    function applyRulesFilter() {
      const query = normalize(rulesSearch.value);
      let visibleCount = 0;

      rules.forEach((rule) => {
        const matchesQuery = !query || normalize(rule.textContent).includes(query);
        const matchesCategory =
          activeCategory === "all" || rule.getAttribute("data-category") === activeCategory;
        const visible = matchesQuery && matchesCategory;

        rule.hidden = !visible;
        if (visible) visibleCount += 1;
      });

      sections.forEach((section) => {
        const hasVisible = Boolean(section.querySelector("[data-rule]:not([hidden])"));
        section.hidden = !hasVisible;
      });

      if (emptyState) emptyState.hidden = visibleCount !== 0;
      if (countEl) countEl.textContent = String(visibleCount);
    }

    rulesSearch.addEventListener("input", applyRulesFilter);

    categoryButtons.forEach((button) => {
      button.addEventListener("click", () => {
        activeCategory = button.getAttribute("data-rule-filter") || "all";
        categoryButtons.forEach((item) => {
          const active = item === button;
          item.classList.toggle("is-active", active);
          item.setAttribute("aria-pressed", String(active));
        });
        applyRulesFilter();
      });
    });

    if (resetButton) {
      resetButton.addEventListener("click", () => {
        rulesSearch.value = "";
        activeCategory = "all";
        categoryButtons.forEach((button) => {
          const active = button.getAttribute("data-rule-filter") === "all";
          button.classList.toggle("is-active", active);
          button.setAttribute("aria-pressed", String(active));
        });
        applyRulesFilter();
        rulesSearch.focus();
      });
    }

    applyRulesFilter();
  }

  /* FAQ filter ------------------------------------------------------------- */
  const faqSearch = $("#faq-search");

  if (faqSearch) {
    const faqItems = $$(".accordion[data-faq]");
    const faqGroups = $$("[data-faq-group]");
    const faqEmpty = $("#faq-empty");
    const faqHint = $("#faq-hint");
    const faqReset = $("[data-faq-reset]");

    const normalize = (value) =>
      value
        .toLowerCase()
        .replace(/ё/g, "е")
        .replace(/\s+/g, " ")
        .trim();

    const plural = (n, forms) => {
      const mod10 = n % 10;
      const mod100 = n % 100;
      if (mod10 === 1 && mod100 !== 11) return forms[0];
      if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return forms[1];
      return forms[2];
    };

    function setInitialHint() {
      if (!faqHint) return;
      faqHint.textContent = `${faqItems.length} ${plural(faqItems.length, [
        "вопрос",
        "вопроса",
        "вопросов",
      ])} · не нашли ответ — напишите нам`;
    }

    function applyFaqFilter() {
      const query = normalize(faqSearch.value);
      let totalVisible = 0;

      faqGroups.forEach((group) => {
        const items = $$(".accordion[data-faq]", group);
        let groupVisible = 0;

        items.forEach((item) => {
          const visible = !query || normalize(item.textContent).includes(query);
          item.hidden = !visible;
          if (visible) groupVisible += 1;
        });

        group.hidden = groupVisible === 0;
        totalVisible += groupVisible;

        const count = $(".faq-group__count", group);
        if (count) count.textContent = String(groupVisible);
      });

      if (faqEmpty) faqEmpty.hidden = totalVisible !== 0;

      if (faqHint) {
        if (!query) {
          setInitialHint();
        } else {
          faqHint.textContent = `Найдено: ${totalVisible} ${plural(totalVisible, [
            "вопрос",
            "вопроса",
            "вопросов",
          ])}`;
        }
      }
    }

    faqSearch.addEventListener("input", applyFaqFilter);

    if (faqReset) {
      faqReset.addEventListener("click", () => {
        faqSearch.value = "";
        applyFaqFilter();
        faqSearch.focus();
      });
    }

    // инициализация счётчиков в заголовках групп
    faqGroups.forEach((group) => {
      const count = $(".faq-group__count", group);
      if (count) count.textContent = String($$(".accordion[data-faq]", group).length);
    });

    setInitialHint();
  }

  /* Buy modal -------------------------------------------------------------- */
  const modal = $("#buy-modal");

  if (modal) {
    const dialog = $(".modal__dialog", modal);
    const itemLabel = $("#modal-item");
    const priceLabel = $("#modal-price");
    const buyForm = $("#buy-form");
    const nickInput = $("#buy-nick");
    let activeTrigger = null;
    let closeTimer = null;

    function openModal(trigger) {
      activeTrigger = trigger;
      const item = trigger.getAttribute("data-item") || "Привилегия";
      const price = trigger.getAttribute("data-price") || "—";

      if (itemLabel) itemLabel.textContent = item;
      if (priceLabel) priceLabel.textContent = price;

      window.clearTimeout(closeTimer);
      modal.hidden = false;
      modal.setAttribute("aria-hidden", "false");
      document.body.classList.add("modal-open");

      window.requestAnimationFrame(() => {
        modal.classList.add("is-open");
        window.setTimeout(() => nickInput?.focus(), 180);
      });
    }

    function closeModal() {
      modal.classList.remove("is-open");
      modal.setAttribute("aria-hidden", "true");
      document.body.classList.remove("modal-open");

      closeTimer = window.setTimeout(() => {
        modal.hidden = true;
        activeTrigger?.focus();
        activeTrigger = null;
      }, 220);
    }

    $$("[data-buy]").forEach((trigger) => {
      trigger.addEventListener("click", () => openModal(trigger));
    });

    $$("[data-modal-close]", modal).forEach((trigger) => {
      trigger.addEventListener("click", closeModal);
    });

    buyForm?.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!buyForm.checkValidity()) {
        buyForm.reportValidity();
        return;
      }

      const nick = nickInput?.value.trim() || "игрок";
      const item = activeTrigger?.getAttribute("data-item") || "покупка";
      buyForm.reset();
      closeModal();
      showToast(
        `Демо-режим: заказ «${item}» для ${nick} сформирован. Платёж не списывался.`
      );
    });

    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || modal.hidden) return;
      closeModal();
    });

    modal.addEventListener("keydown", (event) => {
      if (event.key !== "Tab" || modal.hidden) return;

      const focusable = $$(
        'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        dialog
      ).filter((el) => el.offsetParent !== null);

      if (!focusable.length) return;

      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
  }

  /* Demo forms ------------------------------------------------------------- */
  $$("[data-demo-form]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();

      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const message =
        form.getAttribute("data-demo-message") ||
        "Демо-режим: сообщение отправлено. Спасибо!";
      form.reset();

      if (toastEl) toastEl.classList.remove("is-visible");
      showToast(message);
    });
  });

  /* Global Escape ---------------------------------------------------------- */
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (siteNav?.classList.contains("is-open")) closeNav();
  });
})();
